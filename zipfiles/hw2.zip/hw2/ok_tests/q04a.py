test = {
  'name': 'Question 4a',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> missing_latlongs == 2716
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
