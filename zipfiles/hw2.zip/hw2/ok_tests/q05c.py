test = {
  'name': 'Question 5c',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(ins['year'][0],np.int64)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
