test = {
  'name': 'Question 8c',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> max(ins2016['num_vio']) == 14
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
