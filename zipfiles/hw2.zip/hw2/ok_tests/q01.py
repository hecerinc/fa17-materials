test = {
  'name': 'Question 1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(bus, pd.DataFrame)
          True
          >>> isinstance(ins, pd.DataFrame)
          True
          >>> isinstance(vio, pd.DataFrame)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
