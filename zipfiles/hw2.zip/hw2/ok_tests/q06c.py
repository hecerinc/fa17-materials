test = {
  'name': 'Question 6c',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> numIns2numIDs == {1: 3329, 2: 1131, 3: 83}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
