test = {
  'name': 'Question 5a',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> rows_in_table  == 15430
          True
          >>> unique_ins_ids == 5730
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
