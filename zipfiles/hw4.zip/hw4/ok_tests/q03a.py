
test = {
  'name': 'q03a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> len(theta) == 4
True
>>> (theta[0] > 7864) and (theta[0] < 7866)
True
>>> (theta[1] > -148) and (theta[1] < -146)
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
