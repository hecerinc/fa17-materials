
test = {
  'name': 'q03b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> np.allclose(right_endpoint, 
True
>>>                     np.array([ 2.44691185,  2.17881283,  2.06389856,  2.03693334,  1.98397152,
>>>         1.97189622]))

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
