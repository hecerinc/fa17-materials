
test = {
  'name': 'q02b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> number_of_rows > 53900
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
