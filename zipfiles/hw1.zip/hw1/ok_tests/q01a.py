test = {
  'name': 'Question 1a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> nums_reversed(5)
          '5 4 3 2 1'
          >>> nums_reversed(1)
          '1'
          >>> nums_reversed(3)
          '3 2 1'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
