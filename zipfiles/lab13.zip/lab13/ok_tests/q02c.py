
test = {
  'name': 'q02c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> medalCounts['Simone Biles'] == 5
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
