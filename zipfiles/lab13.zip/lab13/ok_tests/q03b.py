
test = {
  'name': 'q03b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> len(dates) == len(rates)
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
