
test = {
  'name': 'q03a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> type(tree3) == etree._Element
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
