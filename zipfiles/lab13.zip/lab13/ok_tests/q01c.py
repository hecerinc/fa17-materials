
test = {
  'name': 'q01c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> priceInDollars == [2.44, 9.37]
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
