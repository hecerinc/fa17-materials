test = {
  'name': 'Question 5a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> int(bike["propCasual"].sum()) == 2991
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
