
test = {
  'name': 'q00',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> True
True
""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
