Tests are automatically generated
