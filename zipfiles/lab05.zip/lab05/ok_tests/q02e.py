
test = {
  'name': 'q02e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> res_q2e[0] == 'example'
True
>>> res_q2e[1] == 'w3resource'
True
>>> res_q2e[2] == 'github'
True
>>> res_q2e[3] == 'stackoverflow'
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
