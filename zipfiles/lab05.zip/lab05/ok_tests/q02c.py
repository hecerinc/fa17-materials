
test = {
  'name': 'q02c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> res_q2c == ['Python', 'PHP', 'Java']
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
