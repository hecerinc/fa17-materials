
test = {
  'name': 'q02a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> res_q2a == ['10', '20', '30']
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
