
test = {
  'name': 'q02d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> res_q2d == 'PythonExercises'
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
