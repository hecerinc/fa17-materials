
test = {
  'name': 'q05b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> trump['text'].loc['907698529606541312'] == 'it was a great honor to welcome prime minister najib abdul razak of malaysia and his distinguished delegation to th… https://t.co/xihoapazpf'
True
>>> trump['text'].loc['884740553040175104'] == 'working hard to get the olympics for the united states (l.a.). stay tuned!'
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
