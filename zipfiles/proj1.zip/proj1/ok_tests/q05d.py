
test = {
  'name': 'q05d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> tidy_format.loc['907698529606541312'].shape == (24, 2)
True
>>> ' '.join(list(tidy_format.loc['907675638055743489']['word'])) == 'congratulations to eric amp lara on the birth of their son eric luke trump this morning https t co aw0av82xde'
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
