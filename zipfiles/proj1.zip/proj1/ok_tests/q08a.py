
test = {
  'name': 'q08a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> isinstance(fake_counts, pd.DataFrame)
True
>>> 'fake_news' in fake_counts
True
>>> 'total' in fake_counts
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
