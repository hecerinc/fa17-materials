test = {
  'name': 'Question 2c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(lone_ranger, float)
          True
          >>> 10000 < lone_ranger < 20000
          True
          >>> np.round(lone_ranger) == 10537
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
