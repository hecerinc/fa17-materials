test = {
  'name': 'Question 1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> set(map(lambda x:x.strip(),answer1)) == {"THEFT FELONY (OVER $950)","THEFT FROM PERSON","THEFT MISD. (UNDER $950)"}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
