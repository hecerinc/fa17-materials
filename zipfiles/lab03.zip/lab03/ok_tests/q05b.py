test = {
  'name': 'Question 5b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list(answer5b) == ['SHATTUCK AVE', 'UNIVERSITY AVE', 'SAN PABLO AVE', 'TELEGRAPH AVE', 'DURANT AVE']
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
