test = {
  'name': 'Question 3b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> set(answer3b) == {'Friday', 'Saturday'}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
