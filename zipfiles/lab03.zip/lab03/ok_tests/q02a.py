test = {
  'name': 'Question 2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list(map(lambda x:x.strip(),list(answer2a))) == ['LARCENY', 'BURGLARY - VEHICLE', 'VANDALISM', 'DISORDERLY CONDUCT', 'ASSAULT']
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
