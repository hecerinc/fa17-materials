
test = {
  'name': 'q01',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> X_train.shape == (339, 13)
True
>>> X_test.shape == (167, 13)
True
>>> Y_train.shape == (339, )
True
>>> Y_test.shape == (167, )
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
