
test = {
  'name': 'q04',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> best_feature == 'LSTAT'
True
>>> np.abs(best_error - 38.410075117662345) <= 1e-3
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
