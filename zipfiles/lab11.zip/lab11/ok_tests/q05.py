
test = {
  'name': 'q05',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> best_feature_set == ['RM', 'LSTAT', 'PTRATIO']
True
>>> np.abs(best_error - 30.748202560092775) < 1e-3
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
