
test = {
  'name': 'q05',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> (np.allclose(left_endpoint, np.array([ 2.44691185,  2.17881283,  2.06389856,  2.03693334,  1.98397152,
True
>>>         1.97189622])) )

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
