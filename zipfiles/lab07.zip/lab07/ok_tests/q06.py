
test = {
  'name': 'q06',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> ( np.allclose(conf_int_t, np.array([ 97.78049462, 98.17950538])))
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
