
test = {
  'name': 'q03c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> rmse >1522
True
>>> rmse <1523
True
>>> 

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
