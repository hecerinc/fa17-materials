
test = {
  'name': 'q02d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> avg_price_of_diamonds_in_training > 3920
True
>>> avg_price_of_diamonds_in_training < 3922
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
