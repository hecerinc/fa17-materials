
test = {
  'name': 'q03e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> test_rmse < 1400
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
