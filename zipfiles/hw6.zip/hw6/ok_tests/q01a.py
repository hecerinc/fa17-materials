
test = {
  'name': 'q01a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> np.isclose(mean_Y, -0.0278106)
True
>>> np.isclose(sd_Y, 1.0052497653)
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
