
test = {
  'name': 'q02a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> size_of_diamonds > 3100000
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
