
test = {
  'name': 'q01h',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> np.isclose(multiple_R2, 0.86225295102790045)
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
