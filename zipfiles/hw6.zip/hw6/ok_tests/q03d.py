
test = {
  'name': 'q03d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> rmse_improved < 1500
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
